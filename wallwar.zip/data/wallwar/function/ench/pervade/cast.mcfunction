
tag @s add pervade

