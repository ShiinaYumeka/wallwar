
function wallwar:recipe
