
tag @s add pervade

