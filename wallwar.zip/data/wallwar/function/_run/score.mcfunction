
function wallwar:scores
