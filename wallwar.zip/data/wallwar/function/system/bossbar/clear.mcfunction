


bossbar set minecraft:gauge players @a
bossbar set minecraft:gauge2 players @a
bossbar set minecraft:gauge3 players @a
bossbar set minecraft:gauge4 players @a
bossbar set minecraft:gauge5 players @a
bossbar set minecraft:gauge6 players @a
bossbar set minecraft:gauge7 players @a
bossbar set minecraft:gauge8 players @a
bossbar set minecraft:dead_line players @a

bossbar set minecraft:dead_line visible false
bossbar set minecraft:gauge visible false
bossbar set minecraft:gauge2 visible false
bossbar set minecraft:gauge3 visible false
bossbar set minecraft:gauge4 visible false
bossbar set minecraft:gauge5 visible false
bossbar set minecraft:gauge6 visible false
bossbar set minecraft:gauge7 visible false
bossbar set minecraft:gauge8 visible false
