
forceload add ~ ~300 ~ ~
fill ~ -63 ~300 ~ 0 ~1 minecraft:copper_ore replace bedrock
fill ~ 1 ~300 ~ 60 ~1 minecraft:copper_ore replace bedrock
fill ~ 61 ~300 ~ 120 ~1 minecraft:copper_ore replace bedrock
fill ~ 121 ~300 ~ 180 ~1 minecraft:copper_ore replace bedrock
fill ~ 141 ~300 ~ 150 ~1 minecraft:copper_ore replace bedrock

fill ~1 -63 ~300 ~1 0 ~1 minecraft:iron_ore replace bedrock
fill ~1 1 ~300 ~1 60 ~1 minecraft:iron_ore replace bedrock
fill ~1 61 ~300 ~1 120 ~1 minecraft:iron_ore replace bedrock
fill ~1 121 ~300 ~1 180 ~1 minecraft:iron_ore replace bedrock
fill ~1 141 ~300 ~1 150 ~1 minecraft:iron_ore replace bedrock

fill ~-1 -63 ~300 ~-1 0 ~1 minecraft:iron_ore replace bedrock
fill ~-1 1 ~300 ~-1 60 ~1 minecraft:iron_ore replace bedrock
fill ~-1 61 ~300 ~-1 120 ~1 minecraft:iron_ore replace bedrock
fill ~-1 121 ~300 ~-1 180 ~1 minecraft:iron_ore replace bedrock
fill ~-1 141 ~300 ~-1 150 ~1 minecraft:iron_ore replace bedrock
forceload remove ~ ~300 ~ ~


forceload add ~ ~ ~ ~