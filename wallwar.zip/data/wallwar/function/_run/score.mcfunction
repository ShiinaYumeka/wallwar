
function wallwar:scores
