
scoreboard players reset @s choose_starter
scoreboard players enable @s choose_starter
execute unless score @s starter_path matches 0 run return run tellraw @s ["",{"translate":"[战墙] ","color":"gray"},{"translate":"你已经选择过发育流派。","color":"red"}]
execute if score @s choose_starter matches 1 run function wallwar:system/item/starter/mine
execute if score @s choose_starter matches 2 run function wallwar:system/item/starter/farm
execute if score @s choose_starter matches 3 run function wallwar:system/item/starter/axe
execute if score @s choose_starter matches 4 run function wallwar:system/item/starter/fish
execute if score @s choose_starter matches 5 run function wallwar:system/item/starter/potion
execute if score @s choose_starter matches 6 run function wallwar:system/item/starter/build
execute unless score @s starter_path matches 0 run return fail
tellraw @s ["",{"translate":"[战墙] ","color":"gray"},{"translate":"无效选择，请输入 /trigger choose_starter set <1-6>","color":"yellow"}]
