
function wallwar:recipe
