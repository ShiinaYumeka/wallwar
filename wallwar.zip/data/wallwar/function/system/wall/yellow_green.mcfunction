
forceload add ~-300 ~ ~ ~
fill ~-300 -63 ~ ~-1 0 ~ minecraft:copper_ore replace bedrock
fill ~-300 1 ~ ~-1 60 ~ minecraft:copper_ore replace bedrock
fill ~-300 61 ~ ~-1 120 ~ minecraft:copper_ore replace bedrock
fill ~-300 121 ~ ~-1 180 ~ minecraft:copper_ore replace bedrock
fill ~-300 141 ~ ~-1 150 ~ minecraft:copper_ore replace bedrock

fill ~-300 -63 ~1 ~-1 0 ~1 minecraft:iron_ore replace bedrock
fill ~-300 1 ~1 ~-1 60 ~1 minecraft:iron_ore replace bedrock
fill ~-300 61 ~1 ~-1 120 ~1 minecraft:iron_ore replace bedrock
fill ~-300 121 ~1 ~-1 180 ~1 minecraft:iron_ore replace bedrock
fill ~-300 141 ~1 ~-1 150 ~1 minecraft:iron_ore replace bedrock

fill ~-300 -63 ~-1 ~-1 0 ~-1 minecraft:iron_ore replace bedrock
fill ~-300 1 ~-1 ~-1 60 ~-1 minecraft:iron_ore replace bedrock
fill ~-300 61 ~-1 ~-1 120 ~-1 minecraft:iron_ore replace bedrock
fill ~-300 121 ~-1 ~-1 180 ~-1 minecraft:iron_ore replace bedrock
fill ~-300 141 ~-1 ~-1 150 ~-1 minecraft:iron_ore replace bedrock


forceload remove ~-300 ~ ~ ~

forceload add ~ ~ ~ ~