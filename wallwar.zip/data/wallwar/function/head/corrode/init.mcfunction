
tag @s add corrode_init

scoreboard players set #corrode_tid temp -999
execute on origin run scoreboard players operation #corrode_tid temp = @s tid
execute if score #corrode_tid temp matches -999 run scoreboard players operation #corrode_tid temp = @p[gamemode=!spectator] tid

scoreboard players add #corrode_id temp 1
scoreboard players operation @s temp = #corrode_id temp

summon marker ~ ~ ~ {Tags:["corrode_mark","corrode_new"]}
scoreboard players operation @n[type=marker,tag=corrode_new,distance=..1] tid = #corrode_tid temp
scoreboard players operation @n[type=marker,tag=corrode_new,distance=..1] temp = #corrode_id temp
scoreboard players set @n[type=marker,tag=corrode_new,distance=..1] time 3
tag @n[type=marker,tag=corrode_new,distance=..1] remove corrode_new
